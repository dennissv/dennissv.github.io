function round(f, n) {
  return Number.parseFloat(f).toFixed(n);
}

var ph = Math.random() + 6.5;
ph = round(ph, 2);
